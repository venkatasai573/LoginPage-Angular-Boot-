package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Product;
import com.cg.service.CustService;
import com.cg.service.ProdService;
@CrossOrigin("http://localhost:4200")
@RestController
public class CustController {
	@Autowired
	CustService ser;
	@Autowired
	ProdService pSer;
	  @RequestMapping(value = "/login/{username}/{password}")
  	public int  lo(@PathVariable String username,@PathVariable String password) {
  		return ser.loginByUsername(username, password);
  	}
	
	  @RequestMapping(value ="/productsMen")
	  	public List<Product> productM() {
	  		return pSer.getAllProdsM();
	  	}
	 @RequestMapping(value = "/productsWomen")
	  	public List<Product> productW() {
	  		return pSer.getAllProdsW();
	  	}
	  @RequestMapping(value = "/productsKids")
	  	public List<Product> productK() {
	  		return pSer.getAllProdsK();
	  	}
	  
	  @PutMapping(value="/{id}/changepassword/{oldpassword}/{newpassword}/{confirmpassword}")
	  public String changepwd(@PathVariable int id,@PathVariable String oldpassword,@PathVariable String newpassword,@PathVariable String confirmpassword) {
		
		 if(ser.changePwd(id, oldpassword, newpassword, confirmpassword)==true) {
			 
			return "Successfully changed";
			
			 
		 }
		 
		 return "Something Went Wrong";
		  
	  }
	  
	  
}
