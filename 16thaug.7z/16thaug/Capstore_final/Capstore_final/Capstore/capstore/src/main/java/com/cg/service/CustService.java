package com.cg.service;


public interface CustService {
	 public int loginByUsername(String uName, String pwd);
	 public boolean changePwd( int id,String oldpassword, String newpassword, String confirmpassword);
}
