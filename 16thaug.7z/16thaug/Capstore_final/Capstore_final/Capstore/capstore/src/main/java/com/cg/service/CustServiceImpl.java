package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Customer;
import com.cg.dao.CustDao;
@Service
public class CustServiceImpl implements CustService{
	@Autowired
  CustDao dao;
	@Override
	public int loginByUsername(String uName, String pwd) {
		
		Customer cust=dao.getCustomerByUsername(uName);
		 if(cust.getPwd().equals(pwd))
		        return cust.getCust_id();
		return 0;
	}
	@Override
	public boolean changePwd(int id,String oldpassword, String newpassword, String confirmpassword) {
		Customer cust = dao.getOne(id);
		if(cust.getPwd().equals(oldpassword))
		{
			if(newpassword.equals(confirmpassword)) {
				cust.setPwd(newpassword);
				dao.save(cust);
				return true;
			}
		}
		return false;
	}

}
