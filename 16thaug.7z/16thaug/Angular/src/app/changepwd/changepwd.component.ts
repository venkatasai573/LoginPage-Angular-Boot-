import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import{CustserviceService} from '../custservice.service'

@Component({
  selector: 'app-changepwd',
  templateUrl: './changepwd.component.html',
  styleUrls: ['./changepwd.component.css']
})
export class ChangepwdComponent implements OnInit {

  message:string;
  constructor(private router: Router,private userService:CustserviceService ) { }

  ngOnInit() {
  }
  changePassword(id,oldPassword ,newPassword,confirmPassword){

    this.userService.changePassword(id,oldPassword ,newPassword,confirmPassword).subscribe(data=>
{
  this.message=data
  
});
console.log(this.message)
  }



}
