import { Component, OnInit } from '@angular/core';
import {CustserviceService} from '../custservice.service';
import { Router } from '@angular/router';
import { Product } from '../Product';

@Component({
  selector: 'app-women',
  templateUrl: './women.component.html',
  styleUrls: ['./women.component.css']
})
export class WomenComponent implements OnInit {
  prod:Product;
  constructor(private router: Router, private userService: CustserviceService) {

  }
  ngOnInit() {
    this.getWomen();

    
  }
  getWomen() {
   
    this.userService.getWomen().subscribe(data => {
     this.prod=data;
    })
  };

}

