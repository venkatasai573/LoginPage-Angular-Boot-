import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './customer';
import { Product } from './Product'


@Injectable({
  providedIn: 'root'
})
export class CustserviceService {
  id: number;


  constructor(private httpClient: HttpClient) { }
  login(uName, pwd): Observable<number> {
    let url = 'http://localhost:9003/login/' + uName + '/' + pwd;

   return this.httpClient.get<number>(url);
  }

  changePassword(id,oldPassword, newPassword, confirmPassword): Observable<string>{


    let url = 'http://localhost:9003/changepassword/'+oldPassword+'/'+newPassword+'/'+confirmPassword;
    return this.httpClient.put<string>(url,"");


  }
  getMen(): Observable<Product> {
    let url = 'http://localhost:9003/'+setid()+'productsMen';

    return this.httpClient.get<Product>(url);


  }
  getWomen(): Observable<Product> {
    let url = 'http://localhost:9003/productsWomen';

    return this.httpClient.get<Product>(url);


  }
  getKids(): Observable<Product> {
    let url = 'http://localhost:9003/productsKids';

    return this.httpClient.get<Product>(url);


  }

  getid() {
    return this.id;
  }

  setid(id: number) {
    this.id = id;
  }
}
